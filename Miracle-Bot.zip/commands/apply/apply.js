const Discord = require("discord.js");
const cnf = require('../../config.js');

module.exports = {
  name: "apply",
  aliases: ["application"],
  execute: async(client, message, args, data, db) => {
try {
const embed = new Discord.MessageEmbed()
  .setTitle("Apply For Staff Team")
  .setColor('RANDOM')
  .addField("Apply For Staff Team", "[Apply Here (Recomended!)](https://forms.office.com/r/uTz9zfwHTD)\n")
  .setFooter("Bot created by AgentDeath.")
  .setTimestamp()
message.author.send({embed})

message.channel.send({embed: {
            color: 3447003,
            description: "Check a DM message!"
        }})
} catch (err) {
    message.channel.send({embed: {
                color: 16734039,
                description: "Something went wrong... :cry:"
            }})
}
}
}
module.exports.help = {
    name: "apply",
    description: "apply to join the staff team",
    usage: "apply",
    type: "apply"  
}