const Discord = require("discord.js");
const cnf = require('../../config.js');

module.exports = {
  name: "links",
  aliases: ["getlinks", "support", "link"],
  execute: async(client, message, args, data, db) => {

const embed = new Discord.MessageEmbed()
  .setTitle("Invite the bot")
  .setColor('RANDOM')
  .addField("Invite to Discord server", "[Invite the bot here (Recomended!)](https://discord.gg/m8gZ6vbxyV)\n[Invite the bot here (Admin Perm)](https://discord.com/oauth2/authorize?client_id=878341898417348618&scope=bot%20applications.commands&permissions=8)")
  .addField("Support", `[Join to official server](https://discord.gg/m8gZ6vbxyV)`)
    .addField("Our Official Bot Website", `[OFFICAL WEBSITE](www.miraclebot.live)`)
     .addField(`Vote us Here -`, `[Discord Bot list](Coming Soon) [Void Bots](Coming Soon)`)
     .addField(`Apply -`, `[Apply](h)`)
  .setFooter("Bot created by " + `AgentDeath.`)
  .setImage(``)
  .setTimestamp()
message.channel.send({embed})


}
  }



module.exports.help = {
    name: "links",
    description: "Sends a Important Linksvof bot",
    usage: "links",
    type: "General"  
}