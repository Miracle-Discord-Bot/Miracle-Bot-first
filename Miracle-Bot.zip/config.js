
module.exports = {
    "registercommands" : true,
     "token": "ODc4MzQxODk4NDE3MzQ4NjE4.YR_xow.nGJ83TL6Oq_7LjhlqJX-TaM_jcA",
    "imageapi": "81ec44aee6ccbb692dabd2eb0e1454b7f0c5ef1dd805a939a291127eb26b0f5af5bb4a94f095bceade9417c25292e746504e378f2d0f3aa2864c3d775c32e76a",
    "ownerID": ["645713575003815946", "814170568005124137"],
"prefix": ".",
"chat": {
        "url": "http://api.brainshop.ai/get?bid=160813&key=bi3zTfy1zy4f1Ccz&uid=[uid]&msg=[msg]",
        "bid": "160813",
        "key": "bi3zTfy1zy4f1Ccz",
        "uid": "nothing."
    },
    "bid": "874338511464046622",

"api": "AIzaSyCX8Af4p3kAJpjn4189RV2Z8hvMFAMbKoY",
"youtubeAPI": "AIzaSyCX8Af4p3kAJpjn4189RV2Z8hvMFAMbKoY",
mainprefix: ".",
"owner": "AgentDeath.",
"mongourl": "mongodb+srv://bot-list-lol:SzRpE6eXNegtLRvs@cluster0.jme3y.mongodb.net/nothingxd?retryWrites=true&w=majority",
"secret": "NeYsfQRq49Cc_fqVWhKvZZ0B_qe-Zhv8",
 "dashboardURL": "https://miracle-bot.agentdeath.repl.co/dashboard",
defaultjoinmessage: "{user} Joined Invited By {Inviter} (Inviter Invites: {inv})",
defaultleavemessage: "{user} Left, Invited by {inviter}",
  basiclang: "en", //The basic language of the bot, "fr" for French and "en" for English
    embeds: {
        color: "BLUE", //Embed color (in English)
        footers: "GIVEAWAY :tada: :tada:" //Embed footer
    },

    start: {
        loading: "LOADING XD", //Loading status
        activity: "BRUH" //Status
    },

    events: {
        addcolor: "GREEN", //The color of the event add (in English)
        remcolor: "RED" //The color of the event remove (in English)
    },

    reaction: "🎉", //Reaction to the giveaways if you in the console you see 'unknown emoji' that's what this emoji is not recognized by Discord

    grole: "Giveaway Manager", //If the member doesn't have permission to handle messages he can still use the giveaways commands if he has the role configured right here

    auth: {
        support: "https://discord.gg/m8gZ6vbxyV", //The link of your Discord server
        dperms: "8" //The permissions that the bot asks on we want to add it on a Discord server (8 = moderator)
    },
} 